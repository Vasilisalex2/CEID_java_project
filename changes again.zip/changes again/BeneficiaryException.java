public class BeneficiaryException extends IllegalArgumentException
{
    public BeneficiaryException()
    {
        System.out.println("Beneficiary already exists");
    }
}