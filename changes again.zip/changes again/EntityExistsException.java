public class EntityExistsException extends Exception{
    EntityExistsException()
    {
        System.out.println("Entity already exists. ");
    }
}