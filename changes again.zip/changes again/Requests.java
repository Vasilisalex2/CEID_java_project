import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

public class Requests extends RequestDonationList
{
    public void add(int familyMembers,RequestDonation request, RequestDonationList currentDonations, RequestDonationList receivedList, List<Entity> entityList)
    {
              try{
                if(currentDonations.get(request.getEntity().getID()).getQuantity() < request.getQuantity())
                { throw new QuantityException(); }
                else
                { 
                    if(request.getEntity() instanceof Service) { super.add(request, entityList); System.out.println("Entity successfully added. "); }
                    else if(request.getEntity() instanceof Material){
                        if(validRequestDonation(familyMembers, request.getQuantity(), request, receivedList)==true) 
                        { super.add(request, entityList); System.out.println("Entity successfully added. "); }    
                    }
                }
              }
              catch(QuantityException qe){}
    }
    public void modify(int familyMembers,double newQuantity, RequestDonation request, RequestDonationList currentDonations, RequestDonationList receivedList)
    {  //ξαναδες τα μηνυματα
        try{
                if(currentDonations.get(request.getEntity().getID()).getQuantity() < newQuantity )
                { throw new QuantityException(); }
                else
                { 
                    if(request.getEntity() instanceof Service) { super.modify(request, newQuantity); System.out.println("Entity successfully modified. "); }
                    else if(request.getEntity() instanceof Material){
                        if(validRequestDonation(familyMembers, newQuantity, request, receivedList)==true) 
                        {super.modify(request, newQuantity); System.out.println("Entity successfully modified. ");}
                    }
                }
              }
              catch(QuantityException qe){}
    }
    public void commit(int familyMembers, RequestDonationList currentDonations, RequestDonationList receivedList, List<Entity> entityList)
    {
        List <RequestDonation> toRemove = new ArrayList<RequestDonation>();   //δεν μπορούμε να αφαιρέσουμε από το rdEntities ενώ κάνουμε iteration
        System.out.println("Im commiting");
        for(RequestDonation request : rdEntities)
        {
            try{
                if(currentDonations.get(request.getEntity().getID()).getQuantity() < request.getQuantity())
                { throw new QuantityException(); }
                else
                { 
                    double newQuantity = currentDonations.get(request.getEntity().getID()).getQuantity() - request.getQuantity();  //αφαιρω την καινουργια απο την παλια ποσοτητα
                    if(request.getEntity() instanceof Service) 
                    { 
                        currentDonations.get(request.getEntity().getID()).setQuantity(newQuantity); toRemove.add(request); 
                        //receivedList.add(request, entityList);   //θελει εναν ελεγχο, γιατι αν υπαρχει ηδη και πρεπει να ανανεωθει ή αν πρεπει να το προσθεσουμε
                            try {if(receivedList.get(request.getEntity().getID()).getEntity().getID()==request.getEntity().getID()){
                                System.out.println("Im existed");
                                double newQuantity2 = receivedList.get(request.getEntity().getID()).getQuantity() + request.getQuantity();
                                receivedList.get(request.getEntity().getID()).setQuantity(newQuantity2);
                                }}
                            catch(NullPointerException npe){System.out.println("Im newly added");
                                                            receivedList.add(request, entityList);}    
                    }
                    else if(request.getEntity() instanceof Material){
                        if(validRequestDonation(familyMembers, request.getQuantity(), request, receivedList)==true){ 
                              currentDonations.get(request.getEntity().getID()).setQuantity(newQuantity); toRemove.add(request); 
                              //receivedList.add(request, entityList);  
                              try {if(receivedList.get(request.getEntity().getID()).getEntity().getID()==request.getEntity().getID()){
                                System.out.println("Im existed");
                                double newQuantity2 = receivedList.get(request.getEntity().getID()).getQuantity() + request.getQuantity();
                                receivedList.get(request.getEntity().getID()).setQuantity(newQuantity2);
                                }}
                            catch(NullPointerException npe){System.out.println("Im newly added");
                                                            receivedList.add(request, entityList);}
                        }  
                    }
                }
            }
            catch(QuantityException qe){}
        }
        rdEntities.removeAll(toRemove);
    }
    public boolean validRequestDonation(int familyMembers, double quantity, RequestDonation request, RequestDonationList receivedList){  //ορισμα quantiy για τις 2 μεθοδους που την αξιοποιουν
          //το request.entity είναι η υπερκλάση δεν περιλαμβάνει τα getLevel   
          boolean result = false;
          try{
              if(familyMembers == 1)
              {
                  if(quantity + receivedList.get(request.getEntity().getID()).getQuantity() >= ((Material)request.getEntity()).getLevel1()) { throw new ValidityException(); }  
                  else{ result = true; } 
              }      
              if(familyMembers >= 5)
              {
                  if(quantity + receivedList.get(request.getEntity().getID()).getQuantity() >= ((Material)request.getEntity()).getLevel3()){ throw new ValidityException(); }   
                  else{ result = true; } 
              }
              else 
              {
                  if(quantity + receivedList.get(request.getEntity().getID()).getQuantity() >= ((Material)request.getEntity()).getLevel2()){ throw new ValidityException(); }  
                  else{ result = true; } 
              } 
          }
              catch(ValidityException ve){} 
          return result; 
         }
}