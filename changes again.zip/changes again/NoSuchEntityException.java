public class NoSuchEntityException extends Exception{
    public NoSuchEntityException()
    {
        System.out.println("No such entity exists");
    }
}
