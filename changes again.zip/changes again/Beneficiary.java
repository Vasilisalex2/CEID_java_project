import java.util.Scanner;
import java.util.List;
public class Beneficiary extends User
{
    private int noPersons = 1;
    private RequestDonationList receivedList = new RequestDonationList();
    private Requests requestList = new Requests();
    public Beneficiary()
    {
        System.out.println("Enter number of family members: ");
        noPersons = Integer.parseInt(keyboard.nextLine());
    }
    public int getNoPersons() {
        return noPersons;
    }
    public RequestDonation getRequest(int ID)
    {
        return requestList.get(ID);
    }
    public void addRequest(Entity entity, RequestDonationList currentDonations, List<Entity> entityList)  
    {
        RequestDonation request = new RequestDonation(entity);
        requestList.add(getNoPersons(), request, currentDonations, getReceivedList(), entityList); 
    }
    public void modifyRequest(RequestDonation request, RequestDonationList currentDonations) 
    {
        System.out.println("Enter new quantity: ");
        double newQuantity = Double.parseDouble(keyboard.nextLine());
        requestList.modify(getNoPersons(), newQuantity, request, currentDonations, getReceivedList() );
    }
    public void removeRequest(RequestDonation request)
    {
        requestList.remove(request);
    }
    public void commit(RequestDonationList currentDonations, List<Entity> entityList)   //εβαλα ορισμα και το currentDonations, θα το εισάγω από το μενού
    {
        requestList.commit(getNoPersons(), currentDonations, getReceivedList(), entityList); 
    }
    public void printRequestList()
    {
        requestList.monitor();
    }
    public void clearRequestList()
    {
        requestList.reset();
    }
    public RequestDonationList getReceivedList()
    {
        return receivedList;
    }
    public void clearReceivedList()
    {
        receivedList.reset();
    }
     public void printReceivedList()
    {
        receivedList.monitor();
    }
}