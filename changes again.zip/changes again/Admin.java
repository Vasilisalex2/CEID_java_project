public class Admin extends User{
    public boolean isAdmin()
    {
        return true;
    }
}