import java.util.List;
import java.util.ArrayList;
public class RequestDonationList
{
    protected List<RequestDonation> rdEntities = new ArrayList<RequestDonation>();
    public RequestDonation get(int ID) //diavase ksana ekfonisi
    { 
        RequestDonation RD = new RequestDonation();
        for(RequestDonation thisRD : rdEntities) 
        {
             if(thisRD.getEntity().getID() == ID)  RD = thisRD;
        }    
        return RD;
    }
    public void add(RequestDonation RD, List<Entity> entityList){ //θέλει μια μέθοδο που να ψάχνει αν το entity ανήκει στο entityList
        boolean exists = false;
        boolean exists1 = false;
        try{
            for(int i=0; i<entityList.size(); i++)
            {
                if(entityList.get(i).getID() == RD.getEntity().getID() ) exists = true;
            }
            if(exists == false) { throw new NoSuchEntityException(); }
            else{
                for(RequestDonation thisRD : rdEntities){
                    if(thisRD.getEntity().getID() == RD.getEntity().getID()){
                       thisRD.setQuantity(thisRD.getQuantity() + RD.getQuantity());
                       exists1 = true;   
                       break;
                    } 
                }
                if(exists1==false){ rdEntities.add(RD); }
            }
        } catch(NoSuchEntityException nse){}
    }
    public void remove(RequestDonation RD){ rdEntities.remove(RD); }
    public void modify(RequestDonation RD, double newQuantity){ 
        RD.setQuantity(newQuantity);
    } 
    public void monitor(){
        int number = 0;
        for(RequestDonation thisRD : rdEntities){
            System.out.println( thisRD.getEntity().getName() + " in quantity of " + thisRD.getQuantity() );
            number++;
        }
        if(number==0) System.out.println("The list is empty. ");
    }
    public void monitor2(){}
    public void reset() { rdEntities.clear(); } 
}