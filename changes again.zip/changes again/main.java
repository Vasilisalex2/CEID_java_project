public class main
{
    public static void main (String[] args){
        Organization org= new Organization();
        org.setAdmin();
        org.addEntity();
        org.addEntity();
        org.insertDonator();
        Menu menu=new Menu(org);
    }
}
