import java.util.Scanner;
public class Material extends Entity{
    private final double level1; 
    private final double level2;
    private final double level3;
    public Material()
    {
        System.out.println ("Quantity eligible for one member family?");
        level1 = Double.parseDouble(keyboard.nextLine());
        System.out.println ("Quantity eligible for two-four member family?");
        level2 = Double.parseDouble(keyboard.nextLine());
        System.out.println ("Quantity eligible for five or more member family?");
        level3 = Double.parseDouble(keyboard.nextLine());
    }
    public String getDetails()
    {
        return "Type: Material \nOne member families:" + getLevel1() + "\nTwo-four member families: " + getLevel2() + "\nFive or more member families: " + getLevel3();
    }
    public double getLevel1()
    {
        return level1;
    }
    public double getLevel2()
    {
        return level2;
    }
    public double getLevel3()
    {
        return level3;
    }
}
