public class Service extends Entity
{
    public String getDetails()
    {
        return "Type: Service";
    }
}