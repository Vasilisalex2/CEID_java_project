public class QuantityException extends IllegalArgumentException
{
    public QuantityException()
    {
        System.out.println("Quantity not available");
    }
}