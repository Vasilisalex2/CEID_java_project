public class DonatorException extends IllegalArgumentException
{
    public DonatorException()
    {
        System.out.println("Donator already exists");
    }
}
